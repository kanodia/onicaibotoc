import { type AccessGate, type AccessGateConfig, ActionScope, type BlobReference, type BotChatContext, type BotChatEvent, type BotCommunityEvent, type BotCommunityOrGroupContext, type BotEvent, type BotEventWrapper, type BotLifecycleEvent, type BotMessageContext, type ChatEvent, type ChatEventsCriteria, type ChatEventsResponse, type ChatEventWrapper, type ChatIdentifier, type ChatSummaryResponse, type CommandActionScope, type CommandArg, type CommunityEvent, type CommunityEventsCriteria, type CommunityOrGroup, type CompletedCryptocurrencyTransfer, type CreateChannelResponse, DecodedJwt, type DeleteChannelResponse, type FailedCryptocurrencyTransfer, type GroupPermissions, type InstallationLocation, type MessageContent, type MessageEvent, type MessagePermissions, type MiniAppCard, type MiniAppContent, type MiniAppGame, type MiniAppGameUpdate, type PermissionRole, type PriceChartContent, type RawCommandJwt, type SenderContext, type SendMessageResponse, type Success, type ThreadSummary, type TipsReceived } from "../domain";
import type { BotInstallationEventsResponse, ChangeRoleResponse, CommunityEventsResponse, CommunityEventWrapper, CommunitySummaryResponse, MembersResponse, OCError, UserSummaryResponse } from "../domain/response";
import { type AccessGate as ApiAccessGate, type AccessGateConfig as ApiAccessGateConfig, type AccessGateNonComposite as ApiAccessGateNonComposite, type BlobReference as ApiBlobReference, type BotChatContext as ApiBotChatContext, type BotChatEvent as ApiBotChatEvent, type BotCommunityEvent as ApiBotCommunityEvent, type BotCommunityOrGroupContext as ApiBotCommunityOrGroupContext, type BotEvent as ApiBotEvent, type BotEventWrapper as ApiBotEventWrapper, type BotInstallationLocation as ApiBotInstallationLocation, type BotLifecycleEvent as ApiBotLifecycleEvent, type BotMessageContext as ApiBotMessageContext, Chat as ApiChat, type ChatEvent as ApiChatEvent, type LocalUserIndexChatEventsEventsSelectionCriteria as ApiChatEventsCriteria, type CommunityEvent as ApiCommunityEvent, type CommunityCommunityEventsEventsSelectionCriteria as ApiCommunityEventsCriteria, type CommunityOrGroup as ApiCommunityOrGroup, type CommunityPermissionRole as ApiCommunityPermissionRole, type CommunityRole as ApiCommunityRole, type CompletedCryptoTransaction as ApiCompletedCryptoTransaction, type EventWrapperChatEvent as ApiEventWrapperChatEvent, type EventWrapperCommunityEvent as ApiEventWrapperCommunityEvent, type FailedCryptoTransaction as ApiFailedCryptoTransaction, type GroupPermissions as ApiGroupPermissions, type GroupRole as ApiGroupRole, MembersResponse as ApiMembersResponse, type Message as ApiMessage, type MessageContent as ApiMessageContent, type MessagePermissions as ApiMessagePermissions, type MiniAppContent as ApiMiniAppContent, type OCError as ApiOCError, type GroupPermissionRole as ApiPermissionRole, type PriceChartContent as ApiPriceChartContent, type SenderContext as ApiSenderContext, type ThreadSummary as ApiThreadSummary, type LocalUserIndexBotChangeRoleResponse as BotChangeRoleResponse, type LocalUserIndexBotChatEventsResponse as BotChatEventsResponse, type LocalUserIndexBotChatSummaryResponse as BotChatSummaryResponse, BotCommandArg, type CommunityCommunityEventsResponse as BotCommunityEventsResponse, type LocalUserIndexBotCommunitySummaryResponse as BotCommunitySummaryResponse, type LocalUserIndexBotCreateChannelResponse as BotCreateChannelResponse, type UnitResult as BotDeleteChannelResponse, type LocalUserIndexBotSendMessageResponse as BotSendMessageResponse, type Chat, UserIndexBotInstallationEventsResponse, UserIndexUserResponse } from "../typebox/typebox";
type ApiPrincipal = Uint8Array | number[] | string;
export declare function unitResult(value: "Success" | {
    Success: unknown;
} | {
    SuccessV2: unknown;
} | {
    Error: ApiOCError;
}): Success | OCError;
export declare function mapResult<I, O>(value: {
    Success: I;
} | {
    SuccessV2: I;
} | {
    Error: ApiOCError;
}, mapper: (input: I) => O): O | OCError;
export declare function ocError(error: ApiOCError): OCError;
export declare function mapCommandJwt(jwtStr: string, json: RawCommandJwt): DecodedJwt;
export declare function mapCommandScope(api: CommandActionScope): ActionScope;
export declare function mapChatIdentifier(api: Chat): ChatIdentifier;
export declare function membersResponse(api: ApiMembersResponse): MembersResponse;
export declare function sendMessageResponse(api: BotSendMessageResponse): SendMessageResponse;
export declare function createChannelResponse(api: BotCreateChannelResponse): CreateChannelResponse;
export declare function changeRoleResponse(api: BotChangeRoleResponse): ChangeRoleResponse;
export declare function deleteChannelResponse(api: BotDeleteChannelResponse): DeleteChannelResponse;
export declare function communitySummaryResponse(api: BotCommunitySummaryResponse): CommunitySummaryResponse;
export declare function chatSummaryResponse(api: BotChatSummaryResponse): ChatSummaryResponse;
export declare function chatEventsResponse(api: BotChatEventsResponse): ChatEventsResponse;
export declare function communityEventsResponse(api: BotCommunityEventsResponse): CommunityEventsResponse;
export declare function accessGate(api: ApiAccessGate): AccessGate;
export declare function credentialArguments(value: [string, {
    String: string;
} | {
    Int: number;
}][]): Record<string, string | number>;
export declare function apiBlobReference(domain: BlobReference): ApiBlobReference;
export declare function apiAccessGateConfig(domain: AccessGateConfig): ApiAccessGateConfig;
export declare function apiAccessGate(domain: AccessGate): ApiAccessGate;
export declare function apiLeafAccessGate(domain: AccessGate): ApiAccessGateNonComposite;
export declare function permissionRole(api: ApiPermissionRole | ApiGroupRole | ApiCommunityRole | ApiCommunityPermissionRole): PermissionRole;
export declare function apiPermissionRole(domain: PermissionRole): ApiPermissionRole;
export declare function apiGroupRole(domain: PermissionRole): ApiGroupRole;
export declare function apiMessagePermissions(domain: MessagePermissions): ApiMessagePermissions;
export declare function apiGroupPermissions(domain: GroupPermissions): ApiGroupPermissions;
export declare function apiOptional<A, B>(domain: A | undefined, mapper: (a: A) => B): B | undefined;
export declare function optional<A, B>(api: A | null | undefined, mapper: (a: A) => B): B | undefined;
export declare function identity<A>(a: A): A;
export declare function principalStringToBytes(principal: string): Uint8Array;
export declare function consolidateBytes(bytes: Uint8Array | number[]): Uint8Array;
export declare function principalBytesToString(value: Uint8Array | number[] | string): string;
export declare function toRecord2<T, K extends string | number | symbol, V>(xs: T[], keyFn: (x: T) => K, valFn: (x: T) => V): Record<K, V>;
export declare function communityEventWrapper(value: ApiEventWrapperCommunityEvent): CommunityEventWrapper;
export declare function eventWrapper(value: ApiEventWrapperChatEvent): ChatEventWrapper;
export declare function communityEvent(value: ApiCommunityEvent): CommunityEvent;
export declare function event(value: ApiChatEvent): ChatEvent;
export declare function message(value: ApiMessage): MessageEvent;
export declare function messageContent(value: ApiMessageContent, sender: string): MessageContent;
export declare function completedCryptoTransfer(value: ApiCompletedCryptoTransaction, sender: string, recipient: string): CompletedCryptocurrencyTransfer;
export declare function failedCryptoTransfer(value: ApiFailedCryptoTransaction, recipient: string): FailedCryptocurrencyTransfer;
export declare function bytesToBigint(bytes: Uint8Array | number[]): bigint;
export declare function bytesToHexString(bytes: Uint8Array | number[]): string;
export declare function priceChartContent(value: ApiPriceChartContent): PriceChartContent;
export declare function apiPriceChartContent(domain: Omit<PriceChartContent, "kind">): ApiPriceChartContent;
export declare function miniAppContent(value: ApiMiniAppContent): MiniAppContent;
export declare function apiMiniAppContent(domain: Omit<MiniAppContent, "kind">): ApiMiniAppContent;
export type ApiMiniAppGame = {
    chat: {
        Group: string;
    } | {
        Channel: [string, number];
    };
    thread: number | null;
    message_id: string;
};
export declare function miniAppGame(value: ApiMiniAppGame): MiniAppGame;
export declare function apiMiniAppGame(domain: MiniAppGame): ApiMiniAppGame;
export type ApiMiniAppCard = {
    text: string;
    app: string;
    max_players?: number;
    spectators: boolean;
    app_size: {
        width: number;
        height: number;
    };
};
export declare function apiMiniAppCard(domain: MiniAppCard): ApiMiniAppCard;
export type ApiMiniAppPostArgs = {
    token: string;
    card: ApiMiniAppCard;
    block_level_markdown: boolean;
    replies_to: number | null;
};
export type ApiMiniAppGameUpdate = {
    game: ApiMiniAppGame;
    status?: "Finished";
    waiting_for?: string[];
    result?: string;
    end_state?: unknown;
    remove?: string[];
    state?: {
        seq: number;
        shared: unknown;
        private?: Record<string, unknown>;
    };
};
export declare function apiMiniAppGameUpdate(domain: MiniAppGameUpdate): ApiMiniAppGameUpdate;
export declare function threadSummary(value: ApiThreadSummary): ThreadSummary;
export declare function tips(value: [ApiPrincipal, [ApiPrincipal, bigint][]][]): TipsReceived;
export declare function senderContext(value: ApiSenderContext): SenderContext;
export declare function botMessageContext(value: ApiBotMessageContext): BotMessageContext;
export declare function botCommandArg(api: BotCommandArg): CommandArg;
export declare function apiChatEventsCriteria(domain: ChatEventsCriteria): ApiChatEventsCriteria;
export declare function apiCommunityEventsCriteria(domain: CommunityEventsCriteria): ApiCommunityEventsCriteria;
export declare function apiBotCommunityOrGroupContext(domain: BotCommunityOrGroupContext): ApiBotCommunityOrGroupContext;
export declare function apiCommunityOrGroup(domain: CommunityOrGroup): ApiCommunityOrGroup;
export declare function apiBotChatContext(domain: BotChatContext): ApiBotChatContext;
export declare function apiChatIdentifier(domain: ChatIdentifier): ApiChat;
export declare function botEventWrapper(api: ApiBotEventWrapper): BotEventWrapper;
export declare function botEvent(api: ApiBotEvent): BotEvent;
export declare function botChatEvent(api: ApiBotChatEvent): BotChatEvent;
export declare function botCommunityEvent(api: ApiBotCommunityEvent): BotCommunityEvent;
export declare function botLifecycleEvent(api: ApiBotLifecycleEvent): BotLifecycleEvent;
export declare function installationLocation(api: ApiBotInstallationLocation): InstallationLocation;
export declare function userSummaryResponse(api: UserIndexUserResponse): UserSummaryResponse;
export declare function installationEventsResponse(api: UserIndexBotInstallationEventsResponse): BotInstallationEventsResponse;
export {};
