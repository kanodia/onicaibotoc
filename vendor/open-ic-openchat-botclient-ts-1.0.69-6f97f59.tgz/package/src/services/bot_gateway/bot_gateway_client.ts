import { HttpAgent } from "@dfinity/agent";
import type {
    BotChatContext,
    BotClientConfig,
    BotCommunityOrGroupContext,
    ChangeRoleResponse,
    ChannelIdentifier,
    ChatEventsCriteria,
    ChatEventsResponse,
    ChatSummaryResponse,
    CommunityEventsCriteria,
    CommunityEventsResponse,
    CommunityIdentifier,
    CommunitySummaryResponse,
    CreateChannelResponse,
    DeleteChannelResponse,
    MembersResponse,
    Message,
    PermissionRole,
    SendMessageResponse,
    UnitResult,
} from "../../domain";
import type { Channel } from "../../domain/channel";
import {
    apiBotChatContext,
    apiBotCommunityOrGroupContext,
    apiChatEventsCriteria,
    apiCommunityEventsCriteria,
    apiGroupRole,
    changeRoleResponse,
    chatEventsResponse,
    chatSummaryResponse,
    communityEventsResponse,
    communitySummaryResponse,
    createChannelResponse,
    deleteChannelResponse,
    membersResponse,
    principalStringToBytes,
    sendMessageResponse,
    unitResult,
} from "../../mapping";
import {
    MembersResponse as ApiMembersResponse,
    UnitResult as ApiUnitResult,
    LocalUserIndexBotAddReactionArgs as BotAddReactionArgs,
    LocalUserIndexBotChangeRoleArgs as BotChangeRoleArgs,
    LocalUserIndexBotChangeRoleResponse as BotChangeRoleResponse,
    LocalUserIndexBotChatEventsArgs as BotChatEventsArgs,
    LocalUserIndexBotChatEventsResponse as BotChatEventsResponse,
    LocalUserIndexBotChatSummaryArgs as BotChatSummaryArgs,
    LocalUserIndexBotChatSummaryResponse as BotChatSummaryResponse,
    LocalUserIndexBotCommunityEventsArgs as BotCommunityEventsArgs,
    CommunityCommunityEventsResponse as BotCommunityEventsResponse,
    LocalUserIndexBotCommunitySummaryArgs as BotCommunitySummaryArgs,
    LocalUserIndexBotCommunitySummaryResponse as BotCommunitySummaryResponse,
    LocalUserIndexBotCreateChannelArgs as BotCreateChannelArgs,
    LocalUserIndexBotCreateChannelResponse as BotCreateChannelResponse,
    LocalUserIndexBotDeleteChannelArgs as BotDeleteChannelArgs,
    UnitResult as BotDeleteChannelResponse,
    LocalUserIndexBotDeleteMessagesArgs as BotDeleteMessagesArgs,
    LocalUserIndexBotEditMessageArgs as BotEditMessageArgs,
    LocalUserIndexBotMembersArgs as BotMemberArgs,
    LocalUserIndexBotMiniAppPostTokenArgs as BotMiniAppPostTokenArgs,
    LocalUserIndexBotMiniAppPostTokenResponse as BotMiniAppPostTokenResponse,
    LocalUserIndexBotMiniAppTokenResponse as BotMiniAppTokenResponse,
    LocalUserIndexBotSendMessageArgs as BotSendMessageArgs,
    LocalUserIndexBotSendMessageResponse as BotSendMessageResponse,
    Empty,
    MemberType,
    OgPreview,
} from "../../typebox/typebox";
import { MsgpackCanisterAgent } from "../canisterAgent/msgpack";

export class BotGatewayClient extends MsgpackCanisterAgent {
    constructor(
        canisterId: string,
        agent: HttpAgent,
        protected env: BotClientConfig,
    ) {
        super(agent, canisterId);
    }

    members(
        ctx: BotCommunityOrGroupContext,
        memberTypes: MemberType[],
        channelId?: bigint,
    ): Promise<MembersResponse> {
        return this.executeMsgpackQuery(
            "bot_members",
            {
                community_or_group_context: apiBotCommunityOrGroupContext(ctx),
                channel_id: channelId,
                member_types: memberTypes,
            },
            membersResponse,
            BotMemberArgs,
            ApiMembersResponse,
        ).catch((err) => {
            console.error("Call to bot_members failed with: ", JSON.stringify(err));
            throw err;
        });
    }

    sendMessage(
        ctx: BotChatContext,
        message: Message,
        ogPreviews?: OgPreview[],
    ): Promise<SendMessageResponse> {
        return this.executeMsgpackUpdate(
            "bot_send_message",
            message.toInputArgs(ctx, ogPreviews),
            sendMessageResponse,
            BotSendMessageArgs,
            BotSendMessageResponse,
        ).catch((err) => {
            console.error("Call to bot_send_message failed with: ", JSON.stringify(err));
            throw err;
        });
    }

    // A bot edits its own messages autonomously, as OpenChat refuses an edit made with a command's
    // context
    editMessage(
        ctx: BotChatContext,
        messageId: bigint,
        message: Message,
        ogPreviews?: OgPreview[],
    ): Promise<UnitResult> {
        return this.executeMsgpackUpdate(
            "bot_edit_message",
            message.toEditArgs(ctx, messageId, ogPreviews),
            unitResult,
            BotEditMessageArgs,
            ApiUnitResult,
        ).catch((err) => {
            console.error("Call to bot_edit_message failed with: ", JSON.stringify(err));
            throw err;
        });
    }

    deleteMessages(
        ctx: BotChatContext,
        messageIds: bigint[],
        threadRootMessageIndex?: number,
    ): Promise<UnitResult> {
        return this.executeMsgpackUpdate(
            "bot_delete_messages",
            {
                chat_context: apiBotChatContext(ctx),
                message_ids: messageIds,
                thread: threadRootMessageIndex,
            },
            unitResult,
            BotDeleteMessagesArgs,
            ApiUnitResult,
        ).catch((err) => {
            console.error("Call to bot_delete_messages failed with: ", JSON.stringify(err));
            throw err;
        });
    }

    addReaction(
        ctx: BotChatContext,
        reaction: string,
        messageId: bigint,
        threadRootMessageIndex?: number,
    ): Promise<UnitResult> {
        return this.executeMsgpackUpdate(
            "bot_add_reaction",
            {
                chat_context: apiBotChatContext(ctx),
                message_id: messageId,
                reaction,
                thread: threadRootMessageIndex,
            },
            unitResult,
            BotAddReactionArgs,
            ApiUnitResult,
        ).catch((err) => {
            console.error("Call to bot_add_reaction failed with: ", JSON.stringify(err));
            throw err;
        });
    }

    createChannel(
        communityId: CommunityIdentifier,
        channel: Channel,
    ): Promise<CreateChannelResponse> {
        return this.executeMsgpackUpdate(
            "bot_create_channel",
            channel.toInputArgs(communityId),
            createChannelResponse,
            BotCreateChannelArgs,
            BotCreateChannelResponse,
        ).catch((err) => {
            console.error("Call to bot_create_channel failed with: ", JSON.stringify(err));
            throw err;
        });
    }

    deleteChannel(id: ChannelIdentifier): Promise<DeleteChannelResponse> {
        return this.executeMsgpackUpdate(
            "bot_delete_channel",
            { channel_id: BigInt(id.channelId), community_id: id.communityId },
            deleteChannelResponse,
            BotDeleteChannelArgs,
            BotDeleteChannelResponse,
        ).catch((err) => {
            console.error("Call to bot_delete_channel failed with: ", JSON.stringify(err));
            throw err;
        });
    }

    changeRole(
        ctx: BotChatContext,
        userIds: string[],
        newRole: PermissionRole,
    ): Promise<ChangeRoleResponse> {
        return this.executeMsgpackUpdate(
            "bot_change_role",
            {
                chat_context: apiBotChatContext(ctx),
                user_ids: userIds.map(principalStringToBytes),
                new_role: apiGroupRole(newRole),
            },
            changeRoleResponse,
            BotChangeRoleArgs,
            BotChangeRoleResponse,
        ).catch((err) => {
            console.error("Call to bot_change_role failed with: ", JSON.stringify(err));
            throw err;
        });
    }

    communitySummary(communityId: CommunityIdentifier): Promise<CommunitySummaryResponse> {
        return this.executeMsgpackQuery(
            "bot_community_summary",
            { community_id: principalStringToBytes(communityId.communityId) },
            communitySummaryResponse,
            BotCommunitySummaryArgs,
            BotCommunitySummaryResponse,
        ).catch((err) => {
            console.error("Call to bot_chat_summary failed with: ", JSON.stringify(err));
            throw err;
        });
    }

    chatSummary(ctx: BotChatContext): Promise<ChatSummaryResponse> {
        return this.executeMsgpackQuery(
            "bot_chat_summary",
            { chat_context: apiBotChatContext(ctx) },
            chatSummaryResponse,
            BotChatSummaryArgs,
            BotChatSummaryResponse,
        ).catch((err) => {
            console.error("Call to bot_chat_summary failed with: ", JSON.stringify(err));
            throw err;
        });
    }

    chatEvents(
        ctx: BotChatContext,
        criteria: ChatEventsCriteria,
        thread?: number,
    ): Promise<ChatEventsResponse> {
        return this.executeMsgpackQuery(
            "bot_chat_events",
            {
                chat_context: apiBotChatContext(ctx),
                events: apiChatEventsCriteria(criteria),
                thread,
            },
            chatEventsResponse,
            BotChatEventsArgs,
            BotChatEventsResponse,
        ).catch((err) => {
            console.error("Call to bot_chat_events failed with: ", JSON.stringify(err));
            throw err;
        });
    }

    communityEvents(
        communityId: CommunityIdentifier,
        criteria: CommunityEventsCriteria,
    ): Promise<CommunityEventsResponse> {
        return this.executeMsgpackQuery(
            "bot_community_events",
            {
                community_id: principalStringToBytes(communityId.communityId),
                events: apiCommunityEventsCriteria(criteria),
            },
            communityEventsResponse,
            BotCommunityEventsArgs,
            BotCommunityEventsResponse,
        ).catch((err) => {
            console.error("Call to bot_community_events failed with: ", JSON.stringify(err));
            throw err;
        });
    }

    // A token, lasting an hour, which says which bot is calling OpenChat's MiniApp service. Any
    // LocalUserIndex gives one, as they all know every bot.
    async miniAppBotToken(): Promise<string> {
        const resp = await this.executeMsgpackQuery(
            "bot_mini_app_token",
            {},
            (resp) => resp,
            Empty,
            BotMiniAppTokenResponse,
        ).catch((err) => {
            console.error("Call to bot_mini_app_token failed with: ", JSON.stringify(err));
            throw err;
        });
        // Thrown here, not in the mapper, so that a refusal isn't retried as a failed call would be
        if (resp === "NotAuthorized") {
            throw new Error("Unable to get a MiniApp bot token: NotAuthorized");
        }
        if ("InternalError" in resp) {
            throw new Error(`Unable to get a MiniApp bot token: ${resp.InternalError}`);
        }
        return resp.Success;
    }

    // A token to post one MiniApp card through OpenChat's MiniApp service, for the chat the bot
    // would send a message in, with the same options: the channel for a community's command, the
    // thread, and the message id, which a command's token fixes and an autonomous post must give
    async miniAppPostToken(
        ctx: BotChatContext,
        options: { channelId?: bigint; thread?: number; messageId?: bigint },
    ): Promise<string> {
        const resp = await this.executeMsgpackQuery(
            "bot_mini_app_post_token",
            {
                chat_context: apiBotChatContext(ctx),
                channel_id: options.channelId,
                thread: options.thread,
                message_id: options.messageId,
            },
            (resp) => resp,
            BotMiniAppPostTokenArgs,
            BotMiniAppPostTokenResponse,
        ).catch((err) => {
            console.error("Call to bot_mini_app_post_token failed with: ", JSON.stringify(err));
            throw err;
        });
        // Thrown here, not in the mapper, so that a refusal isn't retried as a failed call would be
        if ("Error" in resp) {
            const [code, message] = resp.Error;
            throw new Error(`Unable to get a MiniApp post token: ${code} ${message ?? ""}`.trim());
        }
        return resp.Success;
    }
}
