import type { InstallationLocation } from "./bot";
import { ChatIdentifier, CommunityIdentifier } from "./identifiers";
export declare abstract class ActionScope {
    abstract readonly kind: "chat" | "community";
    abstract toString(): string;
    static fromString(scopeStr: string): ActionScope;
    isChatScope(): this is ChatActionScope;
    isCommunityScope(): this is CommunityActionScope;
    isContainedBy(location: InstallationLocation): boolean;
    abstract isParentOf(scope: ActionScope): this is CommunityActionScope;
}
export declare class ChatActionScope extends ActionScope {
    readonly chat: ChatIdentifier;
    readonly kind: "chat";
    constructor(chat: ChatIdentifier);
    toString(): string;
    isParentOf(_: ActionScope): this is CommunityActionScope;
}
export declare class CommunityActionScope extends ActionScope {
    readonly communityId: CommunityIdentifier;
    readonly kind: "community";
    constructor(communityId: CommunityIdentifier);
    toString(): string;
    isParentOf(scope: ActionScope): this is CommunityActionScope;
}
