export declare abstract class Identifier {
    abstract readonly kind: "direct_chat" | "group_chat" | "channel" | "community";
    abstract canisterId(): string;
    isCommunity(): this is CommunityIdentifier;
    isDirectChat(): this is DirectChatIdentifier;
    isMultiUserChat(): this is MultiUserChatIdentifier;
    isChannel(): this is ChannelIdentifier;
    isGroupChat(): this is GroupChatIdentifier;
}
export declare class CommunityIdentifier extends Identifier {
    readonly communityId: string;
    readonly kind: "community";
    constructor(communityId: string);
    static fromJson(json: any): CommunityIdentifier;
    canisterId(): string;
}
export declare abstract class ChatIdentifier extends Identifier {
    abstract readonly kind: "direct_chat" | "group_chat" | "channel";
    static fromJson(json: any): ChatIdentifier;
}
export declare abstract class MultiUserChatIdentifier extends ChatIdentifier {
    abstract readonly kind: "group_chat" | "channel";
}
export declare class ChannelIdentifier extends MultiUserChatIdentifier {
    readonly communityId: string;
    readonly channelId: bigint;
    readonly kind: "channel";
    constructor(communityId: string, channelId: bigint);
    canisterId(): string;
}
export declare class DirectChatIdentifier extends ChatIdentifier {
    readonly userId: string;
    readonly kind: "direct_chat";
    constructor(userId: string);
    canisterId(): string;
}
export declare class GroupChatIdentifier extends ChatIdentifier {
    readonly groupId: string;
    readonly kind: "group_chat";
    constructor(groupId: string);
    canisterId(): string;
}
