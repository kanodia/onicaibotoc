import type { LocalUserIndexBotEditMessageArgs as BotEditMessageArgs, LocalUserIndexBotSendMessageArgs as BotSendMessageArgs, BotMessageContent as MessageContent, OgPreview } from "../typebox/typebox";
import type { BotChatContext } from "./bot";
import type { BlobReference } from "./data";
import type { MiniAppContent, PriceChartContent, MiniAppSize } from "./event";
import type { MiniAppCard } from "./mini_app";
import type { MessagePermission } from "./permissions";
export type MessageResponse = {
    id: bigint;
    content: MessageContent;
    finalised: boolean;
    block_level_markdown: boolean;
    ephemeral: boolean;
};
export declare abstract class Message {
    #private;
    protected content: MessageContent;
    abstract get requiredMessagePermissions(): MessagePermission[];
    constructor(content: MessageContent);
    makeEphemeral<T extends Message>(): T;
    get isEphemeral(): boolean;
    get channelId(): bigint | undefined;
    setChannelId<T extends Message>(id: bigint): T;
    setFinalised<T extends Message>(finalised: boolean): T;
    setBlockLevelMarkdown<T extends Message>(blm: boolean): T;
    /**
     * Sets the OpenGraph link previews to attach to this message. Setting this - to a populated
     * list *or* to an empty list - disables the client's automatic preview lookup, so passing []
     * is how you explicitly suppress previews for a single message.
     */
    setOgPreviews<T extends Message>(previews: OgPreview[]): T;
    /** The previews explicitly set on this message, or undefined if none were set. */
    get ogPreviews(): OgPreview[] | undefined;
    /** The text of this message, if it is a text message. Used to find links to preview. */
    get text(): string | undefined;
    /** Whether the text is rendered with block level markdown, eg. headings and lists */
    get blockLevelMarkdown(): boolean;
    /** The event index of the message this one replies to, if any */
    get repliesTo(): number | undefined;
    setMessageId<T extends Message>(messageId?: bigint): T;
    setThread<T extends Message>(thread?: number): T;
    setRepliesTo<T extends Message>(repliesTo?: number): T;
    setContextMessageId<T extends Message>(messageId?: bigint): T;
    toResponse(): MessageResponse;
    toInputArgs(ctx: BotChatContext, ogPreviews?: OgPreview[]): BotSendMessageArgs;
    toEditArgs(ctx: BotChatContext, messageId: bigint, ogPreviews?: OgPreview[]): BotEditMessageArgs;
}
export declare class TextMessage extends Message {
    constructor(text: string);
    get requiredMessagePermissions(): MessagePermission[];
}
export declare class ImageMessage extends Message {
    constructor(width: number, height: number, mimeType: string, blobReference: BlobReference);
    get requiredMessagePermissions(): MessagePermission[];
    setCaption(caption?: string): ImageMessage;
}
export declare class FileMessage extends Message {
    constructor(name: string, mimeType: string, fileSize: number, blobReference: BlobReference);
    get requiredMessagePermissions(): MessagePermission[];
    setCaption(caption?: string): FileMessage;
}
/**
 * A chart of token prices, which OpenChat draws so that readers can see the price at any time.
 * OpenChat refuses a chart with a title over 100 characters, more than 5 series, more than 1,000
 * points across all the series or more than 3 sources.
 */
export declare class PriceChartMessage extends Message {
    constructor(chart: Omit<PriceChartContent, "kind">);
    get requiredMessagePermissions(): MessagePermission[];
}
/** The most characters a MiniApp card's text can have */
export declare const MINI_APP_MAX_TEXT_CHARS = 2000;
/**
 * The most characters an app's name, in the bot's definition and on its cards, can have, each a
 * lowercase ASCII letter, a digit, `-` or `_`
 */
export declare const MINI_APP_MAX_APP_NAME_CHARS = 50;
/** The most players a game can have */
export declare const MINI_APP_MAX_PLAYERS = 100;
/**
 * A bot's card for a game, or another app, it hosts: markdown text, with the players, whose turn it
 * is or the result, and buttons to join, open or watch it, all of which OpenChat draws. They open
 * the bot's app, which the bot serves at `/app` under its endpoint, in a frame. The card names one
 * of the apps in the bot's definition, `BotDefinition.mini_apps`, whose image the frame shows
 * whenever there's no app to show: before it loads, to someone who can't open the game, and once
 * the game is over without an end state. The text, app, player limit and whether others can watch
 * never change, and only OpenChat's MiniApp service writes the card's status, so a card is posted
 * open. It needs the MiniApp permission, and can't be posted in a direct chat. Check it with
 * `validate` before posting it, through the service, with `MiniAppServiceClient.post` and a token
 * from `BotClient.miniAppPostToken`: the service posts every card, so that it knows each game from
 * the moment its card exists, and `sendMessage` refuses one. `setBlockLevelMarkdown` and
 * `setRepliesTo` apply to the post; the message's other settings don't.
 */
export declare class MiniAppMessage extends Message {
    #private;
    /**
     * `app` is the name of one of the bot's apps in its definition, eg. "chess": OpenChat refuses
     * a card whose app isn't there. `appSize` is what the app's laid out for, in CSS pixels: the
     * card shows the app at that aspect ratio, sized before it loads. Each is 1 to 10,000, and
     * neither more than three times the other.
     */
    constructor(app: string, text: string, appSize: MiniAppSize);
    get requiredMessagePermissions(): MessagePermission[];
    /** The most who can play, 1 to 100, so the card can show eg. "2 of 4" */
    setMaxPlayers(maxPlayers?: number): MiniAppMessage;
    /**
     * Whether people who aren't playing can watch: members, and anyone who can see a public chat.
     * They see only the game's shared state.
     */
    setSpectators(spectators: boolean): MiniAppMessage;
    /** The card, as `MiniAppServiceClient.post` takes it */
    get card(): MiniAppCard;
    /** Why OpenChat would refuse this card, with the error it gives, or undefined if it's valid */
    validate(): string | undefined;
}
/**
 * Checks a new MiniApp card as OpenChat does: it's open, as only the MiniApp service writes a
 * card's status, and its text, its app's name, its player limit and its app's size. Whether the app
 * is in the bot's definition is only checked by OpenChat. Returns the error OpenChat would give, or
 * undefined if it's valid.
 */
export declare function validateMiniAppContent(content: Omit<MiniAppContent, "kind">): string | undefined;
/** An app's size is in pixels, no more than this each way, and no taller or wider than this ratio */
export declare const MINI_APP_MAX_SIZE = 10000;
export declare const MINI_APP_MAX_SIZE_RATIO = 3;
/** Why OpenChat would refuse an app's size, or undefined if it's fine */
export declare function validateMiniAppSize(width: number, height: number): string | undefined;
/**
 * Checks a MiniApp card's text as OpenChat does: not blank, and at most 2,000 characters. Returns
 * the error OpenChat would give, or undefined if it's valid.
 */
export declare function validateMiniAppText(text: string): string | undefined;
/**
 * Checks the name of a card's app as OpenChat does: 1 to 50 characters, each a lowercase ASCII
 * letter, a digit, `-` or `_`, eg. "chess", "2048" or "press_counter". Returns the error OpenChat
 * gives a card, or undefined if it's valid. The same rule applies to the names in the bot's
 * definition, where OpenChat words its error differently. Whether the bot's definition has an app
 * of that name is only checked by OpenChat.
 */
export declare function validateMiniAppAppName(app: string): string | undefined;
export type PollDuration = "oneHour" | "oneDay" | "oneWeek";
export declare class PollMessage extends Message {
    constructor(question: string, answers: string[], duration?: PollDuration);
    get requiredMessagePermissions(): MessagePermission[];
    setAllowMultipleVotesPerUser(val: boolean): PollMessage;
    setShowVotesBeforeEndDate(val: boolean): PollMessage;
    setAnonymous(val: boolean): PollMessage;
    setAllowUsersToChangeVote(val: boolean): PollMessage;
}
