import { InstallationRecord, type InstallationLocation } from "./bot";
export declare class InstallationRegistry {
    #private;
    constructor(map?: Map<string, InstallationRecord>);
    set(location: InstallationLocation, newRecord: InstallationRecord): void;
    delete(location: InstallationLocation, timestamp: bigint): boolean;
    get(location: InstallationLocation): InstallationRecord | undefined;
    toMap(): Map<string, string>;
    static fromMap(map: Map<string, string>): InstallationRegistry;
}
