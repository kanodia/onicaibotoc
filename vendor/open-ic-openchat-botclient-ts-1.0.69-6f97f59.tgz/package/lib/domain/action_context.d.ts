import type { BotCommand } from "../typebox/typebox";
import type { BotChatContext, BotCommunityOrGroupContext, RawCommandJwt } from "./bot";
import type { ChatPermission, CommunityPermission, MessagePermission } from "./permissions";
import { Permissions } from "./permissions";
import type { ActionScope } from "./scope";
export declare class ActionContext {
    apiGateway: string;
    scope: ActionScope;
    permissions?: Permissions | undefined;
    command?: BotCommand | undefined;
    messageId?: bigint | undefined;
    thread?: number | undefined;
    jwt?: string | undefined;
    constructor(apiGateway: string, scope: ActionScope, permissions?: Permissions | undefined, command?: BotCommand | undefined, messageId?: bigint | undefined, thread?: number | undefined, jwt?: string | undefined);
    static inAutonomousContext(scope: ActionScope, apiGateway: string, autonomousPermissions?: Permissions): ActionContext;
    static fromCommand(token: string, jwt: RawCommandJwt): ActionContext;
    hasMessagePermission(perm: MessagePermission): boolean;
    hasChatPermission(perm: ChatPermission): boolean;
    hasCommunityPermission(perm: CommunityPermission): boolean;
    chatContext(channelId?: bigint): BotChatContext;
    communityOrGroupChatContext(): BotCommunityOrGroupContext;
}
