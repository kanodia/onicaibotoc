import type { BotPermissions } from "../typebox/typebox";
export declare const chatPermissionList: readonly ["ChangeRoles", "UpdateGroup", "AddMembers", "InviteUsers", "RemoveMembers", "DeleteMessages", "PinMessages", "ReactToMessages", "MentionAllMembers", "StartVideoCall", "ReadMessages", "ReadMembership", "ReadChatSummary"];
type ChatPermissionType = typeof chatPermissionList;
export type ChatPermission = ChatPermissionType[number];
export declare const communityPermissionList: readonly ["ChangeRoles", "UpdateDetails", "InviteUsers", "RemoveMembers", "CreatePublicChannel", "CreatePrivateChannel", "ManageUserGroups", "ReadMembership", "ReadCommunitySummary"];
type CommunityPermissionType = typeof communityPermissionList;
export type CommunityPermission = CommunityPermissionType[number];
export declare const messagePermissionList: readonly ["Text", "Image", "Video", "Audio", "File", "Poll", "Crypto", "Giphy", "Prize", "P2pSwap", "VideoCall", "MiniApp"];
type MessagePermissionType = typeof messagePermissionList;
export type MessagePermission = MessagePermissionType[number];
export type PermissionRole = "none" | "moderator" | "owner" | "admin" | "member";
type LowercaseFirstLetter<T extends string> = T extends `${infer First}${infer Rest}` ? `${Lowercase<First>}${Rest}` : T;
export type LowercaseChatPermission = LowercaseFirstLetter<Exclude<ChatPermission, "ReadMessages" | "ReadMembership" | "ReadChatSummary">>;
export type LowercaseMessagePermission = LowercaseFirstLetter<Exclude<MessagePermission, "MiniApp">>;
export type LowercaseCommunityPermission = LowercaseFirstLetter<Exclude<CommunityPermission, "ReadMembership" | "ReadCommunitySummary">>;
export type GroupPermissions = Record<LowercaseChatPermission, PermissionRole> & {
    tipMessages: PermissionRole;
    messagePermissions: MessagePermissions;
    threadPermissions?: MessagePermissions;
};
export type CommunityPermissions = Record<LowercaseCommunityPermission, PermissionRole>;
export type CustomPermission = {
    subtype: string;
    role: PermissionRole;
};
export type MessagePermissions = Partial<Record<LowercaseMessagePermission, PermissionRole>> & {
    custom: CustomPermission[];
    default: PermissionRole;
};
export declare class Permissions {
    #private;
    private granted_permissions;
    constructor(granted_permissions: BotPermissions);
    get rawPermissions(): {
        message?: number | undefined;
        community?: number | undefined;
        chat?: number | undefined;
    };
    static encodePermissions({ community, chat, message, }: {
        community: CommunityPermission[];
        chat: ChatPermission[];
        message: MessagePermission[];
    }): BotPermissions;
    hasMessagePermission(perm: MessagePermission): boolean;
    hasChatPermission(perm: ChatPermission): boolean;
    hasCommunityPermission(perm: CommunityPermission): boolean;
}
export {};
