import { type BotCommand, type BotPermissions, type Chat } from "../typebox/typebox";
import { CommunityIdentifier, DirectChatIdentifier, GroupChatIdentifier, type ChatIdentifier } from "./identifiers";
import type { ChatPermission, CommunityPermission, MessagePermission } from "./permissions";
import { Permissions } from "./permissions";
import type { ActionScope } from "./scope";
declare class DecodedAuth {
    #private;
    protected granted_permissions: BotPermissions;
    constructor(granted_permissions: BotPermissions);
    hasMessagePermission(perm: MessagePermission): boolean;
    hasChatPermission(perm: ChatPermission): boolean;
    hasCommunityPermission(perm: CommunityPermission): boolean;
}
export declare class DecodedJwt extends DecodedAuth {
    encoded: string;
    bot_api_gateway: string;
    bot: string;
    scope: ActionScope;
    command?: BotCommand | undefined;
    kind: string;
    constructor(encoded: string, bot_api_gateway: string, bot: string, scope: ActionScope, granted_permissions: BotPermissions, command?: BotCommand | undefined);
}
export declare function installationLocationFromJSON(json: any): InstallationLocation;
export type InstallationLocation = CommunityIdentifier | GroupChatIdentifier | DirectChatIdentifier;
export declare function chatIdentifierToInstallationLocation(chatId: ChatIdentifier): InstallationLocation;
export declare class InstallationRecord {
    apiGateway: string;
    grantedCommandPermissions: Permissions;
    grantedAutonomousPermissions: Permissions;
    lastUpdated: bigint;
    constructor(apiGateway: string, grantedCommandPermissions: Permissions, grantedAutonomousPermissions: Permissions, lastUpdated: bigint);
    toString(): string;
    static fromString(str: string): InstallationRecord;
}
export type RawCommandJwt = {
    exp: number;
    claim_type: string;
    bot_api_gateway: string;
    bot: string;
    scope: CommandActionScope;
    granted_permissions: BotPermissions;
    command?: BotCommand;
};
export type DecodedPayload = DecodedJwt;
export type CommandActionChatScope = {
    Chat: {
        chat: Chat;
        thread?: number;
        message_id?: bigint;
    };
};
export type CommandActionScope = CommandActionChatScope | CommandActionCommunityScope;
export type CommandActionCommunityScope = {
    Community: string;
};
export type BotCommandUserValue = {
    User: Uint8Array;
};
export type BotClientConfig = {
    openStorageCanisterId: string;
    icHost: string;
    identityPrivateKey: string;
    openchatPublicKey: string;
    userIndexCanisterId?: string;
    autoFetchOgPreviews?: boolean;
    previewProxyUrl?: string;
};
export type CommandArg = CommandArgCommon & CommandArgType;
export type CommandArgCommon = {
    name: string;
};
export type CommandArgType = UserArg | BooleanArg | StringArg | IntegerArg | DecimalArg | DateTimeArg;
export type UserArg = {
    kind: "user";
    userId?: string;
};
export type BooleanArg = {
    kind: "boolean";
    value?: boolean;
};
export type StringArg = {
    kind: "string";
    value?: string;
};
export type IntegerArg = {
    kind: "integer";
    value: bigint | null;
};
export type DecimalArg = {
    kind: "decimal";
    value: number | null;
};
export type DateTimeArg = {
    kind: "dateTime";
    value?: bigint | null;
};
export type BotChatContext = CommandChatContext | AutonomousChatContext;
export type AutonomousCommunityOrGroup = {
    kind: "autonomous";
    communityOrGroup: CommunityOrGroup;
};
export type CommunityOrGroup = CommunityIdentifier | GroupChatIdentifier;
export type CommandChatContext = {
    kind: "command";
    jwt: string;
};
export type AutonomousChatContext = {
    kind: "autonomous";
    chatId: ChatIdentifier;
};
export type BotCommunityOrGroupContext = CommandChatContext | AutonomousCommunityOrGroup;
export {};
