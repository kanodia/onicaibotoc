import type { LocalUserIndexBotCreateChannelArgs } from "../typebox/typebox";
import type { AccessGateConfig } from "./access";
import type { CommunityIdentifier } from "./identifiers";
import type { LowercaseChatPermission as ChatPermission, LowercaseMessagePermission as MessagePermission, PermissionRole } from "./permissions";
export type Rules = {
    text: string;
    enabled: boolean;
};
export declare class Channel {
    #private;
    name: string;
    description: string;
    setMessagesVisibleToNonMembers(val: boolean): Channel;
    setIsPublic(val: boolean): Channel;
    get isPublic(): boolean;
    setThreadPermissions(perm: MessagePermission, role: PermissionRole): Channel;
    setMessagePermissions(perm: MessagePermission, role: PermissionRole): Channel;
    setGroupPermission(perm: ChatPermission | "tipMessages", role: PermissionRole): Channel;
    setHistoryVisibleToNewJoiners(val: boolean): Channel;
    setRules(text: string): Channel;
    set gateConfig(val: AccessGateConfig | undefined);
    setExternalUrl(val: string | undefined): Channel;
    setAvatar(val: Uint8Array | undefined): Channel;
    setEventsTtl(val: bigint | undefined): Channel;
    constructor(name: string, description: string);
    toInputArgs(communityId: CommunityIdentifier): LocalUserIndexBotCreateChannelArgs;
}
