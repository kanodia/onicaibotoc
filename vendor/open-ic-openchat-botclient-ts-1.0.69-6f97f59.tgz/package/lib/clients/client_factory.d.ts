import type { ActionScope, BotClientConfig } from "../domain";
import { Permissions } from "../domain/permissions";
import { MiniAppServiceClient } from "../services/mini_app";
import { BotClient } from "./bot_client";
import { GlobalClient } from "./global_client";
export declare function isMainnet(icUrl: string): boolean;
export declare class BotClientFactory {
    #private;
    constructor(env: BotClientConfig);
    get env(): BotClientConfig;
    createClientInAutonomouseContext(scope: ActionScope, apiGateway: string, autonomousPermissions?: Permissions): BotClient;
    createClientFromCommandJwt(token: string): BotClient;
    createGlobalClient(): GlobalClient;
    /**
     * A client for OpenChat's MiniApp service, at `url`, for the bot's games. It gets the bot's
     * token for the service from the LocalUserIndex `apiGateway`, which can be any of them, as they
     * all know every bot, eg. a command's, `client.apiGateway`, or an installation's. Making it
     * calls nothing, and it fetches the token when it's first used. Keep the client, as it keeps
     * the token for its hour.
     */
    createMiniAppServiceClient(url: string, apiGateway: string): MiniAppServiceClient;
    /**
     * The user id OpenChat gave the bot when it was registered, which is the `bot` in its tokens,
     * eg. to verify the MiniApp service's with `MiniAppTokens`. It isn't the bot's principal. It's
     * fetched from the UserIndex when first asked for, rather than at startup, as a bot is usually
     * started before it's registered, and kept once found. A failed lookup is tried again next
     * time. It asks the UserIndex in `userIndexCanisterId`, which defaults to OpenChat's on
     * mainnet, so set that for any other environment.
     */
    botId(): Promise<string>;
}
