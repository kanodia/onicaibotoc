import { HttpAgent } from "@dfinity/agent";
import { ActionScope, ChannelIdentifier, ChatActionScope, CommunityActionScope, CommunityIdentifier, FileMessage, ImageMessage, MiniAppMessage, PollMessage, PriceChartMessage, TextMessage, type BotClientConfig, type BotInstallationEventsResponse, type ChangeRoleResponse, type ChatEventsCriteria, type ChatEventsResponse, type ChatIdentifier, type ChatSummaryResponse, type CommunityEventsCriteria, type CommunityEventsResponse, type CommunitySummaryResponse, type CreateChannelResponse, type DeleteChannelResponse, type MembersResponse, type Message, type PermissionRole, type PriceChartContent, type SendMessageResponse, type UnitResult, type UserSummaryResponse } from "../domain";
import type { MiniAppSize } from "../domain";
import type { ActionContext } from "../domain/action_context";
import type { Channel } from "../domain/channel";
import { BotCommand, BotCommandArg, MemberType } from "../typebox/typebox";
export declare class BotClient {
    #private;
    constructor(agent: HttpAgent, env: BotClientConfig, actionContext: ActionContext);
    get command(): BotCommand | undefined;
    addReaction(messageId: bigint, reaction: string, thread?: number): Promise<UnitResult>;
    deleteMessages(messageIds: bigint[], thread?: number): Promise<UnitResult>;
    sendMessage(message: Message): Promise<SendMessageResponse>;
    /**
     * Changes the text, or caption, of one of the bot's own messages to `message`'s, which must be
     * of the same type. OpenChat takes nothing else from the content, so an image stays the same
     * image, and refuses an edit of a poll, a deleted message or a MiniApp card, which never
     * changes. The message's thread (`setThread`), channel (`setChannelId`, for a client in a
     * community's scope), block level markdown and link previews apply.
     *
     * A bot edits its messages autonomously, as OpenChat refuses an edit made with a command's
     * token, so this needs a client from `createClientInAutonomouseContext` and the autonomous
     * permission to send the content's type.
     */
    editMessage(messageId: bigint, message: Message): Promise<UnitResult>;
    createChannel(channel: Channel): Promise<CreateChannelResponse>;
    deleteChannel(channelId: ChannelIdentifier): Promise<DeleteChannelResponse>;
    changeRole(userIds: string[], newRole: PermissionRole): Promise<ChangeRoleResponse>;
    get scope(): ActionScope;
    get chatScope(): ChatActionScope | undefined;
    get communityScope(): CommunityActionScope | undefined;
    get messageId(): bigint | undefined;
    /** The LocalUserIndex the client calls OpenChat through */
    get apiGateway(): string;
    stringArg(name: string): string | undefined;
    booleanArg(name: string): boolean | undefined;
    decimalArg(name: string): number | undefined;
    integerArg(name: string): bigint | undefined;
    userArg(name: string): string | undefined;
    get threadRootMessageId(): number | undefined | null;
    get channelId(): bigint | undefined;
    get communityId(): CommunityIdentifier | undefined;
    get chatId(): ChatIdentifier | undefined;
    get commandTimezone(): string | undefined;
    get commandLanguage(): string | undefined;
    get commandArgs(): BotCommandArg[];
    get commandName(): string | undefined;
    get initiator(): string | undefined;
    createTextMessage(text: string): Promise<TextMessage>;
    createPollMessage(question: string, answers: string[]): Promise<PollMessage>;
    createPriceChartMessage(chart: Omit<PriceChartContent, "kind">): Promise<PriceChartMessage>;
    /**
     * A MiniApp card for a game, whose buttons open the bot's app, at the client's message id. See
     * `MiniAppMessage`. `app` names one of the bot's apps in its definition, whose image the card
     * shows whenever there's no app to show. Check the card with its `validate` before posting it
     * with `MiniAppServiceClient.post`.
     */
    createMiniAppMessage(app: string, text: string, appSize: MiniAppSize): Promise<MiniAppMessage>;
    /**
     * A token to post one MiniApp card through OpenChat's MiniApp service, with
     * `MiniAppServiceClient.post`. The service posts every card, as the bot, so that it knows each
     * game from the moment its card exists, and `sendMessage` refuses one. The token is for the
     * chat the client would send a message in, a command's or an autonomous one, with the same
     * options: `channelId` names the channel for a client in a community's scope, `thread` the
     * thread to post in, and `messageId` the card's message id, if the bot chooses one. A chat
     * command's token fixes the message id, which `messageId` must then match; otherwise, for an
     * autonomous card or a community command's, it's picked here, at random, unless the bot gives
     * one, as OpenChat can't pick one in a query. The token lasts an hour, and posting it twice
     * posts one card, so a bot which got no answer posts it again. It needs the MiniApp permission.
     * Rejects, with OpenChat's error, if the bot isn't given one, eg. as it isn't installed in the
     * chat.
     */
    miniAppPostToken(options?: {
        channelId?: bigint;
        thread?: number;
        messageId?: bigint;
    }): Promise<string>;
    createImageMessage(imageData: Uint8Array, mimeType: string, width: number, height: number): Promise<ImageMessage>;
    createFileMessage(name: string, data: Uint8Array, mimeType: string, fileSize: number): Promise<FileMessage>;
    members(memberTypes: MemberType[], channelId?: bigint): Promise<MembersResponse>;
    chatSummary(channelId?: bigint): Promise<ChatSummaryResponse>;
    communitySummary(communityId: CommunityIdentifier): Promise<CommunitySummaryResponse>;
    chatEvents(criteria: ChatEventsCriteria, thread?: number, channelId?: bigint): Promise<ChatEventsResponse>;
    communityEvents(criteria: CommunityEventsCriteria): Promise<CommunityEventsResponse>;
    userSummary(userId?: string): Promise<UserSummaryResponse>;
    installationEvents(): Promise<BotInstallationEventsResponse>;
}
