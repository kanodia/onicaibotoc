import { HttpAgent } from "@dfinity/agent";
import type { BotClientConfig, BotInstallationEventsResponse, UserSummaryResponse } from "../domain";
import { MsgpackCanisterAgent } from "../services/canisterAgent/msgpack";
export declare class GlobalClient extends MsgpackCanisterAgent {
    protected env: BotClientConfig;
    constructor(agent: HttpAgent, env: BotClientConfig);
    userSummary(userId: string): Promise<UserSummaryResponse>;
    /**
     * The user id OpenChat gave the bot when it was registered, which isn't its principal. It's
     * the `bot` in the bot's tokens. This fails until the bot is registered.
     */
    botId(): Promise<string>;
    installationEvents(): Promise<BotInstallationEventsResponse>;
    private installationEventsPage;
}
