import { HttpAgent } from "@dfinity/agent";
import type { BotChatContext, BotClientConfig, BotCommunityOrGroupContext, ChangeRoleResponse, ChannelIdentifier, ChatEventsCriteria, ChatEventsResponse, ChatSummaryResponse, CommunityEventsCriteria, CommunityEventsResponse, CommunityIdentifier, CommunitySummaryResponse, CreateChannelResponse, DeleteChannelResponse, MembersResponse, Message, PermissionRole, SendMessageResponse, UnitResult } from "../../domain";
import type { Channel } from "../../domain/channel";
import { MemberType, OgPreview } from "../../typebox/typebox";
import { MsgpackCanisterAgent } from "../canisterAgent/msgpack";
export declare class BotGatewayClient extends MsgpackCanisterAgent {
    protected env: BotClientConfig;
    constructor(canisterId: string, agent: HttpAgent, env: BotClientConfig);
    members(ctx: BotCommunityOrGroupContext, memberTypes: MemberType[], channelId?: bigint): Promise<MembersResponse>;
    sendMessage(ctx: BotChatContext, message: Message, ogPreviews?: OgPreview[]): Promise<SendMessageResponse>;
    editMessage(ctx: BotChatContext, messageId: bigint, message: Message, ogPreviews?: OgPreview[]): Promise<UnitResult>;
    deleteMessages(ctx: BotChatContext, messageIds: bigint[], threadRootMessageIndex?: number): Promise<UnitResult>;
    addReaction(ctx: BotChatContext, reaction: string, messageId: bigint, threadRootMessageIndex?: number): Promise<UnitResult>;
    createChannel(communityId: CommunityIdentifier, channel: Channel): Promise<CreateChannelResponse>;
    deleteChannel(id: ChannelIdentifier): Promise<DeleteChannelResponse>;
    changeRole(ctx: BotChatContext, userIds: string[], newRole: PermissionRole): Promise<ChangeRoleResponse>;
    communitySummary(communityId: CommunityIdentifier): Promise<CommunitySummaryResponse>;
    chatSummary(ctx: BotChatContext): Promise<ChatSummaryResponse>;
    chatEvents(ctx: BotChatContext, criteria: ChatEventsCriteria, thread?: number): Promise<ChatEventsResponse>;
    communityEvents(communityId: CommunityIdentifier, criteria: CommunityEventsCriteria): Promise<CommunityEventsResponse>;
    miniAppBotToken(): Promise<string>;
    miniAppPostToken(ctx: BotChatContext, options: {
        channelId?: bigint;
        thread?: number;
        messageId?: bigint;
    }): Promise<string>;
}
