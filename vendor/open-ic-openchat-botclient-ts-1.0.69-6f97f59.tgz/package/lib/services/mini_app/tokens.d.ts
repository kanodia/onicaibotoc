import type { MiniAppPlayerClaims } from "../../domain/mini_app";
export declare const CLAIM_TYPE_MINI_APP_PLAYER = "MiniAppPlayer";
export declare const CLAIM_TYPE_MINI_APP_JOIN = "MiniAppJoin";
export declare const CLAIM_TYPE_MINI_APP_LEAVE = "MiniAppLeave";
export declare const CLAIM_TYPE_MINI_APP_START = "MiniAppStart";
/** The header the service's calls, and a player's app, send their token in */
export declare const MINI_APP_TOKEN_HEADER = "x-oc-jwt";
/**
 * Why a token was refused. `expired` means it was valid until it ran out, and `invalid` anything
 * else, eg. a missing token, a bad signature, another kind of token, or a token for another bot.
 * Answer either with a 401.
 */
export declare class TokenError extends Error {
    readonly kind: "expired" | "invalid";
    constructor(kind: "expired" | "invalid", message: string);
}
/** A header's value, as Node's `req.headers[name]` or fetch's `headers.get(name)` gives it */
export type MiniAppTokenHeader = string | string[] | null | undefined;
/**
 * Verifies the tokens the MiniApp service signs, with its public key, from
 * `MiniAppServiceClient.publicKey()`. Each method takes the `x-oc-jwt` header's value and gives
 * what the token says, or throws a `TokenError`. It checks, in order:
 * 1. that the service signed it;
 * 2. that it's the kind of token expected, as the service signs them all with the same key;
 * 3. that it's for this bot, `botId`, as otherwise one bot's server could pass a token to another;
 * 4. that it hasn't expired.
 *
 * `botId` is the user id OpenChat gave the bot when it was registered, which isn't its principal.
 * `BotClientFactory.botId()` fetches it, once OpenChat has registered the bot, so make this on
 * first use rather than at startup.
 */
export declare class MiniAppTokens {
    #private;
    readonly botId: string;
    constructor(publicKey: string, botId: string);
    /**
     * A player's token, which their app sends with each request to the bot. It lasts an hour, and
     * outlives the player being removed, so check the bot's own player list too.
     */
    verifyPlayer(header: MiniAppTokenHeader, now?: number): MiniAppPlayerClaims;
    /**
     * The service's `POST <endpoint>/mini_app/join`: a user asks to join a game, which the bot
     * answers with a `MiniAppJoinResponse` within 5 seconds. They aren't playing until the service
     * adds them, after the answer, so don't count them as a player until the bot's asked to start.
     */
    verifyJoin(header: MiniAppTokenHeader, now?: number): MiniAppPlayerClaims;
    /**
     * The service's `POST <endpoint>/mini_app/start`: a player asks to start a game, which the bot
     * answers within 5 seconds with `acceptMiniAppStart`, with the game's first state, or
     * `refuseMiniAppStart`. See `MiniAppStart` for the rules.
     */
    verifyStart(header: MiniAppTokenHeader, now?: number): MiniAppPlayerClaims;
    /**
     * The service's `POST <endpoint>/mini_app/leave`: a player left a game, or isn't playing after
     * all, eg. as the bot accepted them too late. The bot answers 200, even for a user who isn't
     * one of its players, as the service retries otherwise.
     */
    verifyLeave(header: MiniAppTokenHeader, now?: number): MiniAppPlayerClaims;
}
