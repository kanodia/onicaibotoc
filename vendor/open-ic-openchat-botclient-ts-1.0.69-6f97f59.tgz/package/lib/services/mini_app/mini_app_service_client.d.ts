import { MiniAppMessage } from "../../domain/message";
import type { MiniAppCard, MiniAppGame, MiniAppGameUpdate } from "../../domain/mini_app";
/** What went wrong with a call to the MiniApp service, by the status it answered with */
export type MiniAppServiceErrorKind = "invalid" | "unauthorized" | "not_bots_game" | "unknown_game" | "finished" | "too_large" | "unavailable";
export declare class MiniAppServiceError extends Error {
    readonly kind: MiniAppServiceErrorKind;
    /** The HTTP status the service answered with, or 0 if it couldn't be reached */
    readonly status: number;
    constructor(kind: MiniAppServiceErrorKind, 
    /** The HTTP status the service answered with, or 0 if it couldn't be reached */
    status: number, message: string);
}
/**
 * A client for OpenChat's MiniApp service's bot API: posting the bot's cards, and updating their
 * games. Every call carries the bot's token, from a LocalUserIndex's `bot_mini_app_token`,
 * which it keeps for its hour, fetching a new one shortly before it expires, or when the service
 * refuses it. Make one with `BotClientFactory.createMiniAppServiceClient`, and keep it.
 */
export declare class MiniAppServiceClient {
    #private;
    constructor(
    /** The service's URL, eg. "https://mini-apps.example.com" */
    url: string, 
    /** Fetches a new bot token */
    getBotToken: () => Promise<string>, options?: {
        fetch?: typeof fetch;
    });
    /**
     * Posts a MiniApp card as the bot, with a token from `BotClient.miniAppPostToken`, and
     * resolves with its game once the card is in the chat. The service posts every card, so that it
     * knows each game from the moment its card exists: `sendMessage` refuses one. `card` is from
     * `BotClient.createMiniAppMessage`, or a `MiniAppMessage`'s `card`: its text, the name of one
     * of the bot's apps, its player limit, whether others can watch, and its app's size. Its text
     * is rendered with block level markdown if `blockLevelMarkdown`, and it replies to the
     * message at the event index `repliesTo`, if any; a `MiniAppMessage`'s own settings are the
     * defaults. A token is for one card, and lasts an hour.
     *
     * With `joinInitiator`, the user whose command the card answers is playing from the moment
     * it's posted, its first player, eg. a game's host. The service doesn't ask the bot, so the
     * bot has them playing already: `BotClient.initiator`. A card posted autonomously has no such
     * user.
     *
     * Posting the same token again posts nothing new, and resolves with the same game, so a bot
     * which got no answer, eg. an `unavailable` error, posts it again with the same token. The game
     * is in the token, `miniAppGameFromPostToken`, so a token that isn't a post token is refused
     * without calling the service.
     */
    post(token: string, card: MiniAppMessage | MiniAppCard, options?: {
        blockLevelMarkdown?: boolean;
        repliesTo?: number;
        joinInitiator?: boolean;
    }): Promise<MiniAppGame>;
    /**
     * Updates one of the bot's games: whose turn it is, which the live card shows, its players (only
     * to take some off) and its state, or ends it, with its result and, as any JSON of at most 16
     * KB, its end state, which OpenChat writes to the card and hands to the bot's app, so the card
     * shows how the game ended. The service relays the state, and writes the card in the chat only
     * when the game finishes. A player starts a game, which the bot answers at
     * `POST <endpoint>/mini_app/start`.
     */
    update(update: MiniAppGameUpdate): Promise<void>;
    /**
     * The service's public key, a PEM, which its tokens are verified with by `MiniAppTokens`. It's
     * fetched when first asked for and kept, or fetched again after a failure.
     */
    publicKey(): Promise<string>;
}
/**
 * The game a post token, from `BotClient.miniAppPostToken`, is for, which the LocalUserIndex fixed
 * when it signed the token. So the bot knows the game before the card is posted, eg. to key it
 * before a join can arrive. Read, not verified: the service verifies the token when the card is
 * posted. Throws if `token` isn't a JWT, or is another kind of token.
 */
export declare function miniAppGameFromPostToken(token: string): MiniAppGame;
