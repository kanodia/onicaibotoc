export declare function random128(): bigint;
export declare function random64(): bigint;
