import type { BotClient } from "../clients/bot_client";
import { BotClientFactory } from "../clients/client_factory";
import { type Permissions } from "../domain";
import type { BotEvent, BotEventParseFailure } from "../domain/bot_events";
export declare function verify(publicKey: string, message: Buffer, base64Sig: string): boolean;
export declare function handleNotification<T>(signature: string, rawNotification: Buffer, factory: BotClientFactory, handler: (client: BotClient, ev: BotEvent, timestamp: bigint, apiGateway: string) => Promise<T>, error: (error: BotEventParseFailure) => T, autonomousPermissions?: Permissions): Promise<T>;
