import type { OgPreview } from "../typebox/typebox";
export declare const MAX_LINK_PREVIEWS = 3;
export declare const DEFAULT_PREVIEW_PROXY_URL = "https://dy7sqxe9if6te.cloudfront.net";
/** Empties the preview cache. Exposed primarily for tests. */
export declare function clearOgPreviewCache(): void;
/**
 * Extracts the urls from the supplied text that we should fetch OpenGraph previews for.
 * Unwraps markdown links, strips the LINK_REMOVED marker, excludes links to OpenChat messages
 * and limits the result to MAX_LINK_PREVIEWS.
 */
export declare function extractEnabledLinks(text?: string): string[];
/**
 * Fetches OpenGraph previews for the supplied urls concurrently.
 *
 * This must *never* throw - a failure to obtain a preview must not stop the message being sent -
 * so every failure mode (bad response, timeout, malformed json, network error) degrades to
 * simply returning fewer previews.
 */
export declare function fetchOgPreviews(urls: string[], proxyUrl: string): Promise<OgPreview[]>;
/**
 * Extracts the links from the supplied text and fetches previews for them. Never throws and
 * makes zero http calls if there is no text or the text contains no eligible links.
 */
export declare function fetchOgPreviewsForText(text: string | undefined, proxyUrl: string): Promise<OgPreview[]>;
