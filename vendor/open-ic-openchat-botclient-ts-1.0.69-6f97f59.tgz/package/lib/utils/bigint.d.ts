export declare function bigIntMax(...args: bigint[]): bigint;
export declare function bigIntMin(...args: bigint[]): bigint;
export declare function toBigInt32(value: string | bigint | number): bigint;
export declare function toBigInt64(value: string | bigint | number): bigint;
export declare function numberToBigInt(value: number): bigint;
