/** The header a player's app sends its token to its bot's server in */
export declare const MINI_APP_TOKEN_HEADER = "x-oc-jwt";
/** A player gets their own part of the game's state, and a token; a spectator gets neither */
export type MiniAppRole = "player" | "spectator";
/**
 * A game's state, as its bot published it. `shared` is what everyone sees, and `private` the
 * player's own part, which a spectator doesn't get.
 */
export type MiniAppState<Shared = unknown, Private = unknown> = {
    seq: number;
    shared: Shared;
    private?: Private;
};
/**
 * OpenChat's answer to a player asking to start the game. A refusal's `message` is the bot's, eg.
 * "Needs 2 players", or why OpenChat couldn't start it.
 */
export type MiniAppStartResult = {
    accepted: boolean;
    message?: string;
};
/** What the app sends OpenChat */
export type MiniAppToOpenChat = {
    kind: "mini_app_ready";
} | {
    kind: "mini_app_token_request";
} | {
    kind: "mini_app_start";
} | {
    kind: "mini_app_drawn";
};
/** What OpenChat sends the app */
export type OpenChatToMiniApp = {
    kind: "initialise_mini_app";
    role: MiniAppRole;
    user_id: string;
    token?: string;
    dark_mode: boolean;
    locale: string;
    finished: boolean;
    settings?: unknown;
} | {
    kind: "mini_app_token";
    token: string;
} | {
    kind: "mini_app_state";
    seq: number;
    shared: unknown;
    private?: unknown;
} | {
    kind: "mini_app_end_state";
    state: unknown;
} | {
    kind: "set_dark_mode";
    dark_mode: boolean;
} | ({
    kind: "mini_app_start_result";
} & MiniAppStartResult);
type Initialise = Extract<OpenChatToMiniApp, {
    kind: "initialise_mini_app";
}>;
type StateMessage = Extract<OpenChatToMiniApp, {
    kind: "mini_app_state";
}>;
/** The parts of a `MessageEvent` the client reads */
export type MiniAppMessageEvent = {
    data: unknown;
    origin: string;
    source: unknown;
};
/** The parts of `window` the client uses */
export interface MiniAppWindow {
    readonly parent: {
        postMessage(message: MiniAppToOpenChat, targetOrigin: string): void;
    };
    readonly location: {
        readonly href: string;
    };
    addEventListener(type: "message", listener: (event: MiniAppMessageEvent) => void): void;
    removeEventListener(type: "message", listener: (event: MiniAppMessageEvent) => void): void;
    requestAnimationFrame?(callback: () => void): unknown;
}
export type ConnectOptions = {
    /** How long to wait for OpenChat to initialise the app, or answer a request. 10s by default. */
    timeoutMs?: number;
    /** How long before a player's token expires to ask for a new one. A minute by default. */
    refreshBeforeExpiryMs?: number;
    /** The window the app runs in, `window` by default */
    window?: MiniAppWindow;
    /** What `MiniAppClient.fetch` calls, the global `fetch` by default */
    fetch?: typeof fetch;
};
/**
 * Connects the app to OpenChat: tells it the app is ready, and resolves once OpenChat has
 * initialised it. Rejects if the page isn't framed, or OpenChat doesn't answer in time. `Shared`
 * and `Private` are the shapes of the bot's state, and `EndState` of the end state it ends a game
 * with.
 *
 * When the game is over, and its card holds how it ended, the client is `finished` from the start:
 * no state comes, and there's no token, so the app shows its end view from `endState`, which
 * OpenChat sends right after initialising it (`onEndState`). A game that finishes while the app is
 * open gets its end state the same way, and no state after it.
 *
 * ```ts
 * const openChat = await connectToOpenChat<Board, Hand, Replay>();
 * render(openChat.state);
 * openChat.onStateChange(render);
 * openChat.onEndState(renderReplay);
 *
 * // A player's move, with their token in the `x-oc-jwt` header
 * await openChat.fetch("api/move", { method: "POST", body: JSON.stringify(move) });
 * ```
 */
export declare function connectToOpenChat<Shared = unknown, Private = unknown, EndState = unknown>(options?: ConnectOptions): Promise<MiniAppClient<Shared, Private, EndState>>;
/**
 * Whether the user's theme was dark as OpenChat opened the app, from the `oc_theme` in the app's
 * URL's fragment, or `undefined` if there's none, eg. from an older OpenChat. Unlike
 * `MiniAppClient.darkMode`, it's known before OpenChat's initialised the app. But a module script
 * can run after the browser first draws the page, so this is in time only for a page whose first
 * paint doesn't depend on the theme, not even its background. Otherwise read `oc_theme` in an
 * inline script in the page's `<head>`, as the README shows.
 *
 * ```ts
 * document.documentElement.dataset.theme = initialDarkMode() ? "dark" : "light";
 * const openChat = await connectToOpenChat();
 * ```
 */
export declare function initialDarkMode(win?: Pick<MiniAppWindow, "location"> | undefined): boolean | undefined;
/** The app's connection to OpenChat, from `connectToOpenChat` */
export declare class MiniAppClient<Shared = unknown, Private = unknown, EndState = unknown> {
    #private;
    /** OpenChat's origin, which the app takes messages from and sends them to */
    readonly openChatOrigin: string;
    constructor(window: MiniAppWindow, 
    /** OpenChat's origin, which the app takes messages from and sends them to */
    openChatOrigin: string, initialise: Initialise, options?: ConnectOptions, state?: StateMessage);
    /** Whether the user is playing the game, or watching it */
    get role(): MiniAppRole;
    /**
     * The user's OpenChat user id if they're a player, including one of a finished game's players.
     * It's empty for a spectator: OpenChat doesn't tell the app who's watching, as anyone with the
     * card on screen is. So it changes with the role: read it again after `onRoleChange`.
     */
    get userId(): string;
    /**
     * A player's token, for the bot's server, which verifies it, or undefined for a spectator. The
     * client asks OpenChat for a new one shortly before it expires.
     */
    get token(): string | undefined;
    /**
     * The game's latest state, or undefined until OpenChat sends one. A game that was over when the
     * app opened gets none: see `endState`.
     */
    get state(): MiniAppState<Shared, Private> | undefined;
    /**
     * Whether the game is over, with how it ended in its card. Then there's no token, `role` is
     * "player" if the user was one of the game's players, and no state comes: the app shows its end
     * view from `endState`.
     */
    get finished(): boolean;
    /**
     * How the game ended, as the bot's end state, or undefined until OpenChat sends it: right after
     * initialising an app opened on a finished game, or as the game finishes while the app is open.
     */
    get endState(): EndState | undefined;
    /** Whether the user has OpenChat's dark theme on */
    get darkMode(): boolean;
    /** The user's language in OpenChat, eg. "en" */
    get locale(): string;
    /**
     * The game's settings, as the bot gave them when it started the game, or undefined before
     * the start or if it gave none. The card keeps them, so they're here whenever the game's open.
     */
    get settings(): unknown;
    /**
     * Calls `callback` when the user's role changes, as OpenChat initialises the app again, eg.
     * after they joined the game. Returns a function which stops it.
     */
    onRoleChange(callback: (role: MiniAppRole) => void): () => void;
    /** Calls `callback` with each new state. Returns a function which stops it. */
    onStateChange(callback: (state: MiniAppState<Shared, Private>) => void): () => void;
    /**
     * Calls `callback` with the game's end state when OpenChat sends it, by when the client is
     * `finished`. Returns a function which stops it.
     */
    onEndState(callback: (state: EndState) => void): () => void;
    /** Calls `callback` whenever the user's theme changes. Returns a function which stops it. */
    onDarkModeChange(callback: (darkMode: boolean) => void): () => void;
    /**
     * Asks OpenChat for a new player token, eg. as the bot's server refused the current one with a
     * 401, resolving with it once OpenChat sends it. Requests made while one is waiting share it.
     * Rejects for a spectator, who has no token, or if OpenChat doesn't answer in time.
     */
    refreshToken(): Promise<string>;
    /**
     * Asks OpenChat to start the game, eg. as the player pressed the app's Start button. OpenChat
     * asks the bot, which starts the game, with the players it chooses, or refuses. Resolves with
     * the answer, or a refusal if OpenChat doesn't answer in time. A start made while one is
     * waiting shares it. Rejects for a spectator.
     */
    start(): Promise<MiniAppStartResult>;
    /**
     * `fetch`, with a player's token in the `x-oc-jwt` header for a request to the bot's server, on
     * the app's own origin, eg. "api/move". A spectator has no token, and nothing elsewhere, eg. an
     * avatar's URL, gets it. If the bot answers a player with a 401, it asks OpenChat for a new
     * token and tries once more, so give it a body it can send twice, eg. a string.
     */
    fetch(input: string | URL, init?: RequestInit): Promise<Response>;
    /**
     * Tells OpenChat the app has drawn what it's for: the game as it is, its lobby, how it ended, or
     * why it can't show them, rather than a placeholder such as a spinner while it waits for the
     * state. OpenChat shows the card's artwork until the app says so, with the app drawn unseen
     * meanwhile, and then the app in its place, so the card goes straight from the artwork to the
     * game. An app that doesn't say is shown a second after its page has loaded, whatever it shows
     * then.
     *
     * Call it after drawing, eg. after each render that isn't a placeholder: it's sent once, after
     * the browser has painted what's drawn, so OpenChat doesn't show the page a frame early.
     */
    drawn(): void;
    /** Stops listening to OpenChat, and rejects a token request or a start still waiting */
    close(): void;
}
/**
 * When a token expires, in ms, from its `exp` claim, or undefined if it can't be read. The app reads
 * it only to know when to ask for a new token: the bot's server is what verifies it.
 */
export declare function tokenExpiry(token: string): number | undefined;
export {};
